
const dateFormat = (date) => {
  return date.toLocaleString();
}

export {
  dateFormat
}