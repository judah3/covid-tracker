import { CovidMap } from "components"
const componentData = [
  { path: "/", component: CovidMap },
]

export default componentData